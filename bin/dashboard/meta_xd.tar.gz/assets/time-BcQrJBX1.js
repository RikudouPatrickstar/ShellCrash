import{W as a,aZ as m}from"./index-CvtbhWKk.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
